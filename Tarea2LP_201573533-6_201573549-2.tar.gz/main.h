//
// Created by Cristian Navarrete on 30-08-16.
//

#ifndef TAREA_2_LP_MAIN_H
#define TAREA_2_LP_MAIN_H

#include <stdio.h>
#include <stddef.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <stdbool.h>
#include <string.h>
#include "Sansano.h"
#include "CartaCurso.h"
#include "lista.h"
#include "libraries/pcg-c-basic-0.9/pcg_basic.h"



#endif //TAREA_2_LP_MAIN_H
